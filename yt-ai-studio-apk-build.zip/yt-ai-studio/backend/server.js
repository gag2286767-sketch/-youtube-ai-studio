// YouTube AI Studio backend: research -> script -> TTS -> images -> FFmpeg
const express = require('express'), cors = require('cors'), fs = require('fs'), path = require('path');
const { execFile } = require('child_process'), { promisify } = require('util'), run = promisify(execFile);
const DATA = path.join(__dirname, 'data'); fs.mkdirSync(DATA, { recursive: true });
const KEY = process.env.GROQ_API_KEY, MODEL = process.env.GROQ_MODEL || 'llama-3.3-70b-versatile';
const VOICES = { male: 'ru-RU-DmitryNeural', female: 'ru-RU-SvetlanaNeural' };
const projects = {}; const pf = id => path.join(DATA, id);
const save = p => fs.writeFileSync(path.join(pf(p.id), 'project.json'), JSON.stringify(p, null, 2));
for (const id of fs.existsSync(DATA) ? fs.readdirSync(DATA) : []) try { projects[id] = JSON.parse(fs.readFileSync(path.join(DATA, id, 'project.json'))); } catch {}

const j = async (url, opt) => { const r = await fetch(url, opt); if (!r.ok) throw new Error(url.slice(0, 60) + ' -> ' + r.status); return r.json(); };
const UA = { 'User-Agent': 'YouTubeAIStudio/0.1 (educational project)' };

// 1. Research: Russian Wikipedia (free, CC BY-SA), sources are saved
async function research(topic) {
  const s = await j(`https://ru.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(topic)}&srlimit=5&format=json`, { headers: UA });
  const out = [];
  for (const h of s.query.search.slice(0, 4)) {
    const e = await j(`https://ru.wikipedia.org/w/api.php?action=query&prop=extracts&explaintext=1&exlimit=1&titles=${encodeURIComponent(h.title)}&format=json`, { headers: UA });
    const pg = Object.values(e.query.pages)[0];
    out.push({ title: h.title, url: 'https://ru.wikipedia.org/wiki/' + encodeURIComponent(h.title.replace(/ /g, '_')), text: (pg.extract || '').slice(0, 6000) });
  }
  if (!out.length) throw new Error('По теме ничего не найдено');
  return out;
}

// 2. Script via free LLM API (Groq). Returns scenes [{text, query}]
async function llm(prompt) {
  if (!KEY) throw new Error('Не задан GROQ_API_KEY в backend/.env');
  const d = await j('https://api.groq.com/openai/v1/chat/completions', { method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + KEY },
    body: JSON.stringify({ model: MODEL, temperature: 0.7, response_format: { type: 'json_object' }, messages: [{ role: 'user', content: prompt }] }) });
  return JSON.parse(d.choices[0].message.content);
}
async function writeScript(topic, minutes, facts, onProg) {
  const target = minutes * 140, parts = ['вступление с интригой', ...Array.from({ length: Math.max(2, Math.round(minutes / 3)) }, (_, i) => `основная часть, блок ${i + 1}`), 'заключение с призывом подписаться'];
  const wordsPer = Math.round(target / parts.length), scenes = [];
  for (let i = 0; i < parts.length; i++) {
    const r = await llm(`Ты сценарист YouTube на русском. Тема: "${topic}". Пиши ${parts[i]} (~${wordsPer} слов), только на основе фактов ниже, не выдумывай. Уже было: ${scenes.slice(-2).map(s => s.text).join(' ').slice(0, 400)}\nФакты:\n${facts}\nВерни JSON {"scenes":[{"text":"2-4 предложения закадрового текста","query":"короткий поисковый запрос для картинки, 1-3 слова"}]} (6-10 сцен).`);
    scenes.push(...r.scenes); onProg(i + 1, parts.length);
  }
  const meta = await llm(`Тема видео: "${topic}". Верни JSON {"title":"цепляющее название до 70 символов","description":"описание 3-4 предложения","thumbnails":["3 идеи миниатюр"]}`);
  return { scenes, meta };
}

// 3. Voice: edge-tts (pip install edge-tts) - free but UNOFFICIAL, no guarantees
const dur = async f => parseFloat((await run('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', f])).stdout);
const tts = (text, voice, out) => run('edge-tts', ['--voice', voice, '--text', text, '--write-media', out]);

// 4. Images: Wikimedia Commons, free licenses only, attribution saved
async function image(query, out) {
  const u = `https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrnamespace=6&gsrlimit=8&gsrsearch=${encodeURIComponent(query)}&prop=imageinfo&iiprop=url|mime|extmetadata&iiurlwidth=1920&format=json`;
  const d = await j(u, { headers: UA }); const pages = Object.values(d.query?.pages || {});
  for (const p of pages) {
    const ii = p.imageinfo?.[0]; const lic = ii?.extmetadata?.LicenseShortName?.value || '';
    if (!ii || !/jpeg|png/.test(ii.mime) || !/CC|Public domain|PD/i.test(lic)) continue;
    const r = await fetch(ii.thumburl, { headers: UA }); if (!r.ok) continue;
    fs.writeFileSync(out, Buffer.from(await r.arrayBuffer()));
    return { source: ii.descriptionurl, license: lic };
  }
  return null;
}

// 5. Assemble with FFmpeg
const srtT = t => { const h = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60), s = (t % 60).toFixed(3).replace('.', ','); return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${s.padStart(6, '0')}`; };
async function buildScene(dir, i, sc, voice, topic) {
  const a = path.join(dir, `s${i}.mp3`), im = path.join(dir, `s${i}.jpg`), v = path.join(dir, `s${i}.mp4`);
  await tts(sc.text, voice, a); const d = await dur(a);
  const credit = await image(sc.query || topic, im).catch(() => null) || await image(topic, im).catch(() => null);
  const frames = Math.ceil(d * 25) + 5;
  const src = credit ? ['-loop', '1', '-i', im] : ['-f', 'lavfi', '-i', 'color=c=0x14161f:s=1920x1080:r=25'];
  const vf = credit ? `scale=2400:-2:force_original_aspect_ratio=increase,crop=2400:1350,zoompan=z='min(zoom+0.0004,1.15)':d=${frames}:s=1920x1080:fps=25,fade=t=in:d=0.4` : 'null';
  await run('ffmpeg', ['-y', ...src, '-i', a, '-vf', vf, '-t', String(d + 0.2), '-r', '25', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-shortest', v]);
  return { d: d + 0.2, credit, v };
}
async function build(p) {
  const dir = pf(p.id), set = (status, progress) => { p.status = status; p.progress = progress; save(p); };
  try {
    set('Поиск информации', 0.03); const src = await research(p.topic); p.sources = src.map(s => ({ title: s.title, url: s.url }));
    set('Написание сценария', 0.1);
    const { scenes, meta } = await writeScript(p.topic, p.minutes, src.map(s => `## ${s.title}\n${s.text}`).join('\n'), (a, b) => set(`Сценарий ${a}/${b}`, 0.1 + 0.2 * a / b));
    Object.assign(p, meta, { scenes }); save(p);
    const done = []; let t = 0, srt = '', n = 1;
    for (let i = 0; i < scenes.length; i++) {
      set(`Сцена ${i + 1}/${scenes.length}`, 0.3 + 0.55 * i / scenes.length);
      const r = await buildScene(dir, i, scenes[i], VOICES[p.voice] || VOICES.male, p.topic); done.push(r);
      const words = scenes[i].text.split(/\s+/), chunks = []; for (let k = 0; k < words.length; k += 9) chunks.push(words.slice(k, k + 9).join(' '));
      chunks.forEach((c, k) => { srt += `${n++}\n${srtT(t + r.d * k / chunks.length)} --> ${srtT(t + r.d * (k + 1) / chunks.length)}\n${c}\n\n`; }); t += r.d;
    }
    fs.writeFileSync(path.join(dir, 'subs.srt'), srt);
    fs.writeFileSync(path.join(dir, 'list.txt'), done.map(r => `file '${r.v}'`).join('\n'));
    set('Монтаж и субтитры', 0.9);
    await run('ffmpeg', ['-y', '-f', 'concat', '-safe', '0', '-i', 'list.txt', '-vf', "subtitles=subs.srt:force_style='FontSize=22,Outline=2,MarginV=40'", '-c:v', 'libx264', '-preset', 'veryfast', '-c:a', 'aac', 'final.mp4'], { cwd: dir, maxBuffer: 1e8 });
    p.credits = done.map(r => r.credit).filter(Boolean); p.videoUrl = `/files/${p.id}/final.mp4`; set('Готово', 1);
  } catch (e) { p.status = 'Ошибка'; p.error = String(e.message || e); save(p); }
}

const app = express(); app.use(cors(), express.json()); app.use('/files', express.static(DATA));
app.get('/projects', (_, r) => r.json(Object.values(projects).sort((a, b) => b.created - a.created)));
app.get('/projects/:id', (q, r) => projects[q.params.id] ? r.json(projects[q.params.id]) : r.sendStatus(404));
app.post('/projects', (q, r) => {
  const { topic, minutes = 10, voice = 'male' } = q.body; if (!topic) return r.status(400).json({ error: 'topic' });
  const id = Date.now().toString(36), p = { id, topic, minutes: Math.min(30, +minutes), voice, status: 'В очереди', progress: 0, created: Date.now() };
  fs.mkdirSync(pf(id), { recursive: true }); projects[id] = p; save(p); build(p); r.json(p);
});
app.listen(process.env.PORT || 3000, () => console.log('backend on', process.env.PORT || 3000));
