import React, { useEffect, useState } from 'react';
import { SafeAreaView, View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, Alert, ScrollView } from 'react-native';
import { Video, ResizeMode } from 'expo-av';
import * as FileSystem from 'expo-file-system';
import * as MediaLibrary from 'expo-media-library';
import { StatusBar } from 'expo-status-bar';

// Адрес вашего backend (IP компьютера в Wi-Fi или https-адрес сервера). Секретных ключей здесь нет.
const API = (process.env.EXPO_PUBLIC_API_URL || 'http://192.168.0.10:3000').replace(/\/$/, '');
const C = { bg: '#0f1117', card: '#1a1d27', acc: '#ff3b57', tx: '#f2f3f7', mu: '#8b90a0' };
const api = (p, o) => fetch(API + p, o).then(r => r.json());

const Chip = ({ on, label, onPress }) => (
  <TouchableOpacity onPress={onPress} style={[s.chip, on && { backgroundColor: C.acc }]}><Text style={{ color: C.tx }}>{label}</Text></TouchableOpacity>);

export default function App() {
  const [topic, setTopic] = useState(''), [minutes, setMinutes] = useState(10), [voice, setVoice] = useState('male');
  const [list, setList] = useState([]), [open, setOpen] = useState(null), [busy, setBusy] = useState(false);
  const load = () => api('/projects').then(setList).catch(() => {});
  useEffect(() => { load(); const t = setInterval(load, 3000); return () => clearInterval(t); }, []);
  const create = async () => {
    if (!topic.trim()) return Alert.alert('Введите тему видео');
    setBusy(true);
    try { await api('/projects', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ topic, minutes, voice }) }); setTopic(''); load(); }
    catch { Alert.alert('Нет связи с сервером', 'Проверьте адрес API в App.js и запущен ли backend'); }
    setBusy(false);
  };
  const exportMp4 = async p => {
    const perm = await MediaLibrary.requestPermissionsAsync(); if (!perm.granted) return Alert.alert('Нужен доступ к галерее');
    const f = await FileSystem.downloadAsync(API + p.videoUrl, FileSystem.documentDirectory + `${p.id}.mp4`);
    await MediaLibrary.saveToLibraryAsync(f.uri); Alert.alert('Сохранено в галерею');
  };
  if (open) {
    const p = list.find(x => x.id === open) || {};
    return (<SafeAreaView style={s.root}><StatusBar style="light" /><ScrollView contentContainerStyle={{ padding: 16 }}>
      <TouchableOpacity onPress={() => setOpen(null)}><Text style={{ color: C.acc }}>‹ Назад</Text></TouchableOpacity>
      <Text style={s.h1}>{p.title || p.topic}</Text>
      {p.videoUrl ? <Video style={{ height: 210, marginVertical: 12 }} source={{ uri: API + p.videoUrl }} useNativeControls resizeMode={ResizeMode.CONTAIN} /> : <Text style={s.mu}>{p.status} · {Math.round((p.progress || 0) * 100)}%</Text>}
      {p.videoUrl && <TouchableOpacity style={s.btn} onPress={() => exportMp4(p)}><Text style={s.btnT}>Экспорт MP4 в галерею</Text></TouchableOpacity>}
      {p.error && <Text style={{ color: C.acc }}>{p.error}</Text>}
      {p.description && <Text style={s.tx}>{p.description}</Text>}
      {p.thumbnails && <><Text style={s.h2}>Идеи миниатюр</Text>{p.thumbnails.map((t, i) => <Text key={i} style={s.tx}>• {t}</Text>)}</>}
      {p.sources && <><Text style={s.h2}>Источники</Text>{p.sources.map((x, i) => <Text key={i} style={s.mu}>{x.title}: {x.url}</Text>)}</>}
      {p.credits && <><Text style={s.h2}>Лицензии изображений</Text>{p.credits.map((x, i) => <Text key={i} style={s.mu}>{x.license}: {x.source}</Text>)}</>}
    </ScrollView></SafeAreaView>);
  }
  return (<SafeAreaView style={s.root}><StatusBar style="light" />
    <FlatList contentContainerStyle={{ padding: 16 }} data={list} keyExtractor={x => x.id}
      ListHeaderComponent={<View>
        <Text style={s.h1}>YouTube AI Studio</Text>
        <TextInput style={s.input} placeholder="Введите тему видео" placeholderTextColor={C.mu} value={topic} onChangeText={setTopic} />
        <Text style={s.mu}>Длительность</Text><View style={s.row}>{[10, 15, 20, 30].map(m => <Chip key={m} on={minutes === m} label={`${m} мин`} onPress={() => setMinutes(m)} />)}</View>
        <Text style={s.mu}>Язык: русский · Голос</Text><View style={s.row}><Chip on={voice === 'male'} label="Мужской" onPress={() => setVoice('male')} /><Chip on={voice === 'female'} label="Женский" onPress={() => setVoice('female')} /></View>
        <TouchableOpacity style={s.btn} onPress={create} disabled={busy}><Text style={s.btnT}>{busy ? '...' : 'Создать видео'}</Text></TouchableOpacity>
        <Text style={s.h2}>Мои видео</Text></View>}
      renderItem={({ item: p }) => (<TouchableOpacity style={s.card} onPress={() => setOpen(p.id)}>
        <Text style={s.tx}>{p.title || p.topic}</Text><Text style={s.mu}>{p.status} · {p.minutes} мин</Text>
        <View style={s.bar}><View style={[s.fill, { width: `${(p.progress || 0) * 100}%` }]} /></View>
        <Text style={{ color: C.acc, marginTop: 6 }}>{p.videoUrl ? 'Предпросмотр / экспорт ›' : 'Открыть ›'}</Text></TouchableOpacity>)} />
  </SafeAreaView>);
}
const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: C.bg }, h1: { color: C.tx, fontSize: 26, fontWeight: '700', marginVertical: 12 }, h2: { color: C.tx, fontSize: 18, fontWeight: '600', marginTop: 20, marginBottom: 8 },
  tx: { color: C.tx, marginVertical: 4 }, mu: { color: C.mu, marginVertical: 4 }, row: { flexDirection: 'row', flexWrap: 'wrap', marginVertical: 6 },
  input: { backgroundColor: C.card, color: C.tx, borderRadius: 12, padding: 14, marginBottom: 10 }, chip: { backgroundColor: C.card, borderRadius: 20, paddingVertical: 8, paddingHorizontal: 14, marginRight: 8, marginBottom: 6 },
  btn: { backgroundColor: C.acc, borderRadius: 12, padding: 15, alignItems: 'center', marginTop: 14 }, btnT: { color: '#fff', fontWeight: '700' },
  card: { backgroundColor: C.card, borderRadius: 14, padding: 14, marginBottom: 10 }, bar: { height: 6, backgroundColor: C.bg, borderRadius: 3, marginTop: 8 }, fill: { height: 6, backgroundColor: C.acc, borderRadius: 3 } });
